import UIKit

//class Car {
//    var colour = "red"
//}
//
//let myCar = Car()
//myCar.colour = "blue"
//
//let youCar = Car()
//
//
//print(youCar.colour)

class Car {
    var colour = "red"
    
    static let singletonCar = Car()
}

let myCar = Car.singletonCar
myCar.colour = "blue"

let youCar = Car.singletonCar

print(youCar.colour)

class A {
    init() {
        Car.singletonCar.colour = "brown"
    }
}

class B {
    init() {
        print(Car.singletonCar.colour)
        Car.singletonCar.colour
    }
}

let a = A()
let b = B()
